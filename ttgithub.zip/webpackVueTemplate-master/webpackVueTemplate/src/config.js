/**
 * Created by tengteng on 17/12/27.
 */

// 请求目标服务器域名配置
const DOMAIN_NAME = {
  URL_EASYMOCK: 'https://easy-mock.com/mock/5a58669d3dcb200788d26fa0/baseUrl/'
};

export default DOMAIN_NAME;
