<template>
  <div class="pageMain">
    <!-- title -->
    <h1>{{msg}}</h1>
    <date></date>
    <h4>Name: {{getUserInfo.name}}</h4>
    <h4>ID: {{getUserInfo.id}}</h4>
    <!-- form -->
    <div class="block-name">
      <label for="name">change name</label>
      <input type="text" id="name" v-model="name">
    </div>
    <div class="block-id">
      <label for="id">change id</label>
      <input type="text" id="id" v-model="id">
    </div>
    <button @click="commitUserInfoFunc">commit</button>
  </div>
</template>

<script>
  // 工具
  import {mapGetters, mapActions} from 'vuex';
  import server from '@/services/server';

  // 组件
  import date from '@/components/date.vue';

  export default{
    data() {
      return {
        msg: 'pageMain',
        name: '',
        id: ''
      }
    },
    created() {
      this.getUserInfoFunc();
      this.getListDataFunc();
    },
    computed: {
      ...mapGetters([
        'getUserInfo'
      ])
    },
    methods: {
      ...mapActions([
        'changeUserInfo'
      ]),
      // vuex中state状态修改
      commitUserInfoFunc() {
        let userInfo = {
          name: this.name,
          id: this.id
        };
        this.changeUserInfo(userInfo);
      },
      // 接口调用
      getUserInfoFunc() {
        server.getUserInfo().then((res) => {
          console.log(res);
        })
      },
      getListDataFunc() {
        server.getListData().then((res) => {
          console.log(res);
        })
      }
    },
    components: {
      date
    }
  }
</script>

<style scoped>
  .pageMain {
    background-color: #fff;
  }
  .pageMain .block-name input,
  .pageMain .block-id input {
    border: 1px solid #ddd;
  }
  .pageMain button {
    display: block;
    margin: 20px auto 0 auto;
    padding: 10px;
    border-radius: 4px;
    color: #fff;
    background-color: green;
  }
</style>
