/**
 * Created by tengteng on 17/12/27.
 */

import axios from '../services/axios';

/**
 * 统一处理所有接口请求
 * 参数对象将会替换axios中默认参数中的键值对，其中可包含：
 * method
 * timeout
 * data
 * headers
 * dataType
 */
const server = {
  getUserInfo(data) {
    return axios('user_info', {
      method: 'get',
      data: data
    });
  },
  getListData(data) {
    return axios('list_query', {
      method: 'get',
      data: data
    });
  }
};

export default server;
