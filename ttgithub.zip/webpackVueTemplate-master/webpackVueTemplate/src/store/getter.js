/**
 * Created by tengteng on 17/12/27.
 */

const getters = {
  getUserInfo(state) {
    return state.userInfo;
  }
};

export default getters;
