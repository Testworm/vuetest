/**
 * Created by tengteng on 17/12/27.
 */

const mutations = {
  changeUserInfo(state, payload) {
    state.userInfo = payload.userInfo;
  }
};

export default mutations;
