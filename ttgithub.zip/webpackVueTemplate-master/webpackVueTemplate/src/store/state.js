/**
 * Created by tengteng on 17/12/27.
 */

const state = {
  userInfo: {
    name: 'admin',
    id: '0001'
  }
};

export default state;
