# webpackVueTemplate
### 在vue-init webpack的基础上封装axios、vuex的模板

### Premise <br>
全局安装Node.js <br>
全局安装vue-cli <br>

### Usage <br>
1：$cd webpackVueTemplate <br>
2：$npm install <br>
3：$npm run dev <br>
4：$npm run build <br>
